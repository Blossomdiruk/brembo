<?php
return [
    'en' => 'English',
    'si' => 'සිංහල',
    'ta' => 'தமிழ்'
];