<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class Warrent_incident extends Model
{
    use HasFactory,Notifiable;
    protected $table = 'warenty_incidents';

    protected $fillable = [
        'product_id',
        'product_name',
        'description',
        'comment',
        'warrenty_status',
        'workshop_id',
        'purchased date'
    ];
}
